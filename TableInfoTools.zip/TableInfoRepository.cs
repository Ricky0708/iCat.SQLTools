﻿using Fz.Report.Common.Managers.Interfaces;
using Fz.Report.Common.Models;
using Fz.Report.Common.Repositories.Interfaces;
using Fz.Report.Common.Services.Interfaces;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fz.Report.Common.Repositories.Implements
{
    /// <summary>
    /// <see cref="ITableInfoRepository"/>
    /// </summary>
    public class TableInfoRepository : ITableInfoRepository
    {
        private readonly ISQLDBManager _sqlDBManager;

        /// <summary>
        /// <see cref="ITableInfoRepository{T}.Category"/>
        /// </summary>
        public string Category { get; private set; }

        /// <summary>
        /// Constructure
        /// </summary>
        /// <param name="sqlDBManager"></param>
        public TableInfoRepository(ISQLDBManager sqlDBManager) : this(sqlDBManager.Category, sqlDBManager)
        {
        }

        /// <summary>
        /// Constructure
        /// </summary>
        /// <param name="sqlDBManager"></param>
        public TableInfoRepository(string category, ISQLDBManager sqlDBManager)
        {
            this._sqlDBManager = sqlDBManager;
            Category = category;
        }

        /// <summary>
        /// <see cref="ITableInfoRepository.DropTable(string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        public void DropTable(string tableName)
        {
            var sbSQL = new StringBuilder();
            sbSQL.Append($"DROP TABLE {tableName}");
            _sqlDBManager.ExecuteNonQuery(sbSQL.ToString(), null);

        }

        /// <summary>
        /// <see cref="ITableInfoRepository.CloneSchemaToNewTable(string, string)"/>
        /// </summary>
        /// <param name="sourceTable"></param>
        /// <param name="createTable"></param>
        /// <returns></returns>
        public string CloneSchemaToNewTable(string sourceTable, string createTable)
        {
            var sbSQL = new StringBuilder();
            sbSQL.Append($"CREATE TABLE {createTable} LIKE {sourceTable}");
            _sqlDBManager.ExecuteNonQuery(sbSQL.ToString(), null);
            return createTable;
        }

        /// <summary>
        /// ITableInfoRepository.IsTableExists(string)
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public bool IsTableExists(string tableName)
        {
            var result = new List<TableSchemaModel>();
            var sbSQL = new StringBuilder();
            sbSQL.Append($"SELECT a.COLUMN_NAME, a.`DATA_TYPE`, a.COLUMN_COMMENT ");
            sbSQL.Append($"FROM information_schema.COLUMNS a ");
            sbSQL.Append($"WHERE a.TABLE_NAME = ?tableName AND TABLE_SCHEMA = DATABASE() ");


            var @params = new MySqlParameter[] {
                new MySqlParameter("?tableName", tableName)
            };

            return _sqlDBManager.ExecuteScalar(sbSQL.ToString(), @params) != null;

        }

        /// <summary>
        /// <see cref="ITableInfoRepository.GetTotalRecords(string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public virtual int GetTotalRecords(string tableName)
        {
            var sbSQL = new StringBuilder();
            sbSQL.Append($"SELECT COUNT(1) FROM {tableName}");

            var result = int.Parse(_sqlDBManager.ExecuteScalar(sbSQL.ToString(), null).ToString());
            return result;
        }

        /// <summary>
        /// <see cref="ITableInfoRepository.HasRecord(string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public bool HasRecord(string tableName)
        {
            var result = new List<TableSchemaModel>();
            var sbSQL = new StringBuilder();
            sbSQL.Append($"SELECT COUNT(1) FROM (SELECT 1 FROM {tableName} LIMIT 1) A ");

            return Convert.ToInt32(_sqlDBManager.ExecuteScalar(sbSQL.ToString(), null)) > 0;
        }

        /// <summary>
        /// <see cref="ITableInfoRepository.GetSchemaInfo(string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public IEnumerable<TableSchemaModel> GetSchemaInfo(string tableName)
        {
            var result = new List<TableSchemaModel>();
            var sbSQL = new StringBuilder();
            sbSQL.Append($"SELECT a.COLUMN_NAME, a.`DATA_TYPE`, a.COLUMN_COMMENT, a.IS_NULLABLE ");
            sbSQL.Append($"FROM information_schema.COLUMNS a ");
            sbSQL.Append($"WHERE a.TABLE_NAME = ?tableName AND TABLE_SCHEMA = DATABASE() ");

            var @params = new MySqlParameter[] {
                new MySqlParameter("?tableName", tableName)
            };

            return _sqlDBManager.ExecuteReader(sbSQL.ToString(), @params, dr =>
            {
                return new TableSchemaModel
                {
                    COLUMN_COMMENT = dr["COLUMN_COMMENT"].ToString(),
                    COLUMN_NAME = dr["COLUMN_NAME"].ToString(),
                    DATA_TYPE = dr["DATA_TYPE"].ToString(),
                    IS_NULLABLE = dr["IS_NULLABLE"].ToString(),
                };
            });
        }

        /// <summary>
        /// <see cref="ITableInfoRepository.RenameTable(string, string)"/>
        /// </summary>
        /// <param name="oriTable"></param>
        /// <param name="newTable"></param>
        public void RenameTable(string oriTable, string newTable)
        {
            var sbSQL = new StringBuilder();
            sbSQL.Append($"RENAME TABLE {oriTable} TO {newTable} ");

            _sqlDBManager.ExecuteNonQuery(sbSQL.ToString(), null);
        }

        /// <summary>
        /// <see cref="ITableInfoRepository.GetAllDatabases"/>
        /// </summary>
        /// <returns></returns>
        public IEnumerable<string> GetAllDatabases()
        {
            var result = new List<TableSchemaModel>();
            var sbSQL = new StringBuilder();
            sbSQL.Append($"SELECT DISTINCT a.TABLE_SCHEMA ");
            sbSQL.Append($"FROM information_schema.COLUMNS a ");

            var @params = new MySqlParameter[] {
            };

            return _sqlDBManager.ExecuteReader(sbSQL.ToString(), @params, dr =>
            {
                return dr["TABLE_SCHEMA"].ToString();
            });
        }

        public IEnumerable<string> GetTableNames()
        {
            var result = new List<TableSchemaModel>();
            var sbSQL = new StringBuilder();
            sbSQL.Append($"SELECT a.TABLE_SCHEMA, a.TABLE_NAME ");
            sbSQL.Append($"FROM information_schema.COLUMNS a ");
            sbSQL.Append($"WHERE TABLE_SCHEMA = DATABASE() ");
            sbSQL.Append($"GROUP BY a.TABLE_SCHEMA, a.TABLE_NAME ");

            var @params = new MySqlParameter[] { };

            return _sqlDBManager.ExecuteReader(sbSQL.ToString(), @params, dr =>
            {
                return dr["TABLE_NAME"].ToString();
            });
        }
    }
}
