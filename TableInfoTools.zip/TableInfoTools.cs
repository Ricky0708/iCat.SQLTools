﻿using Fz.Report.Common.Constants;
using Fz.Report.Common.Repositories.Interfaces;
using Fz.Report.Common.Services.Interfaces;
using Fz.Report.Common.Tools.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fz.Report.Common.Tools.Implements
{
    public class TableInfoTools : ITableInfoTools
    {
        private readonly ITableInfoRepository _tableInfoRepository;

        /// <summary>
        /// <see cref="ITableInfoTools{T}.Category"/>
        /// </summary>
        public string Category { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tableInfoRepository"></param>
        public TableInfoTools(ITableInfoRepository tableInfoRepository) : this(tableInfoRepository.Category, tableInfoRepository)
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="category"></param>
        /// <param name="tableInfoRepository"></param>
        public TableInfoTools(string category, ITableInfoRepository tableInfoRepository)
        {
            _tableInfoRepository = tableInfoRepository ?? throw new ArgumentNullException(nameof(tableInfoRepository));
            Category = category;
        }

        #region operations

        /// <summary>
        /// <see cref="ITableInfoRepository.CloneSchemaToNewTable(string, string)"/>
        /// </summary>
        /// <param name="sourceTable"></param>
        /// <param name="createTable"></param>
        /// <returns></returns>
        public string CloneSchemaToNewTable(string sourceTable, string createTable)
        {
            if (CheckTable(createTable, TableCheckOptionEnum.Exists))
            {
                _tableInfoRepository.DropTable(createTable);
            }
            return _tableInfoRepository.CloneSchemaToNewTable(sourceTable, createTable);
        }

        /// <summary>
        /// <see cref="ITableInfoRepository.GetTotalPages(string, int)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="pageRecords"></param>
        /// <returns></returns>
        public int GetTotalPages(string tableName, int pageRecords)
        {

            var result = GetTotalRecords(tableName);
            var n = result / pageRecords; // 商數
            var m = result - (n * pageRecords); // 餘數
            return m > 0 ? n + 1 : n;
        }

        /// <summary>
        /// <see cref="ITableInfoRepository.GetTotalRecords(string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public int GetTotalRecords(string tableName)
        {
            return _tableInfoRepository.GetTotalRecords(tableName);
        }

        /// <summary>
        /// <see cref="ITableInfoTools.CheckTable(string, TableCheckOptionEnum)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="checkOption"></param>
        /// <returns></returns>
        public bool CheckTable(string tableName, TableCheckOptionEnum checkOption)
        {
            var result = true;
            if ((checkOption & TableCheckOptionEnum.HasRecords) > 0) result = result && _tableInfoRepository.HasRecord(tableName);
            if ((checkOption & TableCheckOptionEnum.Exists) > 0) result = result && _tableInfoRepository.IsTableExists(tableName);
            return result;
        }

        /// <summary>
        /// <see cref="ITableInfoTools.RenameTable(string, string)"/>
        /// </summary>
        /// <param name="oriTable"></param>
        /// <param name="newTable"></param>
        public void RenameTable(string oriTable, string newTable)
        {
            if (_tableInfoRepository.IsTableExists(newTable)) _tableInfoRepository.DropTable(newTable);
            _tableInfoRepository.RenameTable(oriTable, newTable);
        }

        /// <summary>
        /// <see cref="ITableInfoTools.GetTableNames"/>
        /// </summary>
        /// <returns></returns>
        public IEnumerable<string> GetTableNames()
        {
            return _tableInfoRepository.GetTableNames();
        }

        #endregion


        #region get codes

        /// <summary>
        /// <see cref="ITableInfoTools.GetSchemaToProperty(string, string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public string GetSchemaToProperty(string tableName)
        {
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var result = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                result.Append($"/// <summary>\r\n");
                result.Append($"/// {item.COLUMN_COMMENT}\r\n");
                result.Append($"/// </summary>\r\n");
                result.Append($"public {ConvertType(item.DATA_TYPE)}{(item.IS_NULLABLE == "YES" ? "?" : "")} {item.COLUMN_NAME} {{ get; set; }}\r\n");
                result.Append($"\r\n");
            }

            return result.ToString();
        }

        /// <summary>
        /// <see cref="ITableInfoTools.GetDataReaderAssignString(string, string, string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="className"></param>
        /// <returns></returns>
        public string GetDataReaderAssignString(string tableName, string className)
        {
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var result = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                //result.Append($"{item.COLUMN_NAME} = Convert.{ConverCsharpConvertType(item.DATA_TYPE)}(dr[nameof({className}.{item.COLUMN_NAME})]),\r\n");
                result.Append($"{item.COLUMN_NAME} = {(item.IS_NULLABLE == "YES" ? $"dr[nameof({className}.{item.COLUMN_NAME})] as {ConvertType(item.DATA_TYPE)}? ?? null" : $"Convert.{ConverCsharpConvertType(item.DATA_TYPE)}(dr[nameof({className}.{item.COLUMN_NAME})])")},\r\n");

            }


            return result.ToString();
        }

        /// <summary>
        /// <see cref="ITableInfoTools.GetColumnsStatement(string, string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public string GetColumnsStatement(string prefix, string tableName)
        {
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var result = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                result.Append($"{prefix}{item.COLUMN_NAME}, ");

            }
            return result.ToString().Substring(0, result.Length - 2);
        }

        /// <summary>
        /// <see cref="ITableInfoTools.GetSelectStatement(string, string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="tableAliasName"></param>
        /// <returns></returns>
        public string GetSelectStatement(string tableName, string tableAliasName)
        {
            if (string.IsNullOrEmpty(tableAliasName)) tableAliasName = "A";
            var columns = GetColumnsStatement($"{tableAliasName}.", tableName);
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);

            var tempBuilder = new StringBuilder();
            var last = schemaInfo.Last();
            foreach (var item in schemaInfo)
            {
                tempBuilder.Append($"sbSQL.Append($\"    {tableAliasName}.{item.COLUMN_NAME} = ?{item.COLUMN_NAME}{(item.COLUMN_NAME == last.COLUMN_NAME ? "" : ",")} \");\r\n");
            }

            var result = new StringBuilder();
            result.Append($"sbSQL.Append($\"SELECT \");\r\n");
            result.Append($"sbSQL.Append($\"    {columns} \");\r\n");
            result.Append($"sbSQL.Append($\"FROM \");\r\n");
            result.Append($"sbSQL.Append($\"    {tableName} {tableAliasName} \");\r\n");
            result.Append($"sbSQL.Append($\"WHERE \");\r\n");
            result.Append(tempBuilder.ToString());
            //result.Append($"sbSQL.Append($\" \");\r\n");

            return result.ToString();
        }

        /// <summary>
        /// <see cref="ITableInfoTools.GetInsertStatement(string)"/>
        /// </summary>
        /// <param name="tableAliasName"></param>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public string GetInsertStatement(string tableName)
        {
            var columns = GetColumnsStatement($"", tableName);
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var last = schemaInfo.Last();

            var tempBuilder = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                tempBuilder.Append($"?{item.COLUMN_NAME}{(item.COLUMN_NAME == last.COLUMN_NAME ? "" : ", ")}");
            }

            var result = new StringBuilder();
            result.Append($"sbSQL.Append($\"INSERT INTO {tableName} \");\r\n");
            result.Append($"sbSQL.Append($\"    ({columns}) \");\r\n");
            result.Append($"sbSQL.Append($\"VALUES \");\r\n");
            result.Append($"sbSQL.Append($\"    ({tempBuilder.ToString()}) \");\r\n");
            //result.Append($"sbSQL.Append($\" \");\r\n");

            return result.ToString();
        }


        public string GetUpdateStatement(string tableName)
        {
            var columns = GetColumnsStatement($"", tableName);
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var last = schemaInfo.Last();

            var tempBuilder = new StringBuilder();
            var tempBuilderWhere = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                tempBuilder.Append($"{item.COLUMN_NAME} = ?new{item.COLUMN_NAME}{(item.COLUMN_NAME == last.COLUMN_NAME ? "" : ", ")}");
                tempBuilderWhere.Append($"sbSQL.Append($\"   {item.COLUMN_NAME} = ?ori{item.COLUMN_NAME}{(item.COLUMN_NAME == last.COLUMN_NAME ? "" : ",")} \");\r\n");
            }

            var result = new StringBuilder();
            result.Append($"sbSQL.Append($\"UPDATE {tableName} \");\r\n");
            result.Append($"sbSQL.Append($\"SET \");\r\n");
            result.Append($"sbSQL.Append($\"    {tempBuilder.ToString()} \");\r\n");
            result.Append($"sbSQL.Append($\"WHERE \");\r\n");
            result.Append($"{tempBuilderWhere.ToString()}");
            //result.Append($"sbSQL.Append($\" \");\r\n");

            return result.ToString();
        }

        public string GetDeleteStatement(string tableName)
        {
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var last = schemaInfo.Last();

            var tempBuilderWhere = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                tempBuilderWhere.Append($"sbSQL.Append($\"   {item.COLUMN_NAME} = ?{item.COLUMN_NAME}{(item.COLUMN_NAME == last.COLUMN_NAME ? "" : ",")} \");\r\n");
            }

            var result = new StringBuilder();
            result.Append($"sbSQL.Append($\"DELETE FROM {tableName} \");\r\n");
            result.Append($"sbSQL.Append($\"WHERE \");\r\n");
            result.Append($"{tempBuilderWhere.ToString()}");
            //result.Append($"sbSQL.Append($\" \");\r\n");

            return result.ToString();
        }

        public string GetDaoToDtoAssignString(string tableName)
        {
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var result = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                //result.Append($"{item.COLUMN_NAME} = Convert.{ConverCsharpConvertType(item.DATA_TYPE)}(dr[nameof({className}.{item.COLUMN_NAME})]),\r\n");
                result.Append($"{item.COLUMN_NAME} = p.{item.COLUMN_NAME},\r\n");

            }


            return result.ToString();
        }

        /// <summary>
        /// <see cref="ITableInfoTools.GetMergeIntoTableStatement(string, string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public string GetMergeIntoTableStatement(string tableName)
        {
            var columns = GetColumnsStatement("", tableName);
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var result = new StringBuilder();
            result.Append($"sbSQL.Append($\"INSERT INTO \");\r\n");
            result.Append($"sbSQL.Append($\"	{tableName} \");\r\n");
            result.Append($"sbSQL.Append($\"  	({columns}) \");\r\n");
            var tempBuilder = new StringBuilder();
            var tempBuilder2 = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                tempBuilder.Append($"?{item.COLUMN_NAME}{{i}}, ");
                tempBuilder2.Append($"sbSQL.Append($\"  	{item.COLUMN_NAME} = {{{tableName}}}.{item.COLUMN_NAME} + newData.{item.COLUMN_NAME}, \");\r\n");
            }
            result.Append($"sbSQL.Append($\"	VALUES \");\r\n");
            result.Append($"sbSQL.Append($\"  	({tempBuilder.ToString().Substring(0, tempBuilder.Length - 2)}) \");\r\n");
            result.Append($"sbSQL.Append($\"	AS newData \");\r\n");
            result.Append($"sbSQL.Append($\"ON DUPLICATE KEY UPDATE \");\r\n");
            result.Append(tempBuilder2.ToString());
            return result.ToString();
        }

        /// <summary>
        /// <see cref="ITableInfoTools.GetParamAttachments(string, string, string)"/>
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="varModelName"></param>
        /// <param name="paramPrefix"></param>
        /// <returns></returns>
        public string GetParamAttachments(string tableName, string varModelName, string paramPrefix = "")
        {
            var schemaInfo = _tableInfoRepository.GetSchemaInfo(tableName);
            var result = new StringBuilder();
            foreach (var item in schemaInfo)
            {
                result.Append($"@params.Add(new MySqlParameter($\"?{paramPrefix}{item.COLUMN_NAME}\", {varModelName}.{item.COLUMN_NAME}));\r\n");

            }
            return result.ToString();
        }

        #endregion


        #region private methods

        private object ConverCsharpConvertType(string type)
        {
            switch (type)
            {
                case "longtext":
                case "varchar":
                    return nameof(Convert.ToString);
                case "decimal":
                    return nameof(Convert.ToDecimal);
                case "bigint":
                    return nameof(Convert.ToInt64);
                case "tinyint":
                    return nameof(Convert.ToBoolean);
                case "int":
                    return nameof(Convert.ToInt32);
                case "time":
                case "date":
                case "datetime":
                    return nameof(Convert.ToDateTime);
                default:
                    throw new Exception("wrong type");
            }
        }

        private string ConvertType(string type)
        {
            
            switch (type)
            {
                case "longtext":
                case "text":
                case "varchar":
                    return "string";
                case "decimal":
                    return "decimal";
                case "bigint":
                    return "long";
                case "tinyint":
                    return "bool";
                case "int":
                    return "int";
                case "time":
                    return "TimeSpan";
                case "timestamp":
                case "date":
                case "datetime":
                    return "DateTime";
                default:
                    throw new Exception("wrong type");
            }
        }



        #endregion

    }
}
